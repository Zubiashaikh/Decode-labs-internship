# Security Specification: Firestore Threat Matrix

This security specification details the Data Invariants, the "Dirty Dozen" exploitation payloads, and the automated rules test suite to protect the ApexSaaS Firestore integration.

---

## 1. Data Invariants

1. **Testimonial Ownership**: A user must only create testimonials carrying their own validated `request.auth.uid`. Testimonials cannot be spoofed.
2. **Submissions Temporal Integrity**: Timestamps (`createdAt`) for users, subscribers, and testimonials must strictly match the server time `request.time`.
3. **Email Subscriptions Sanitation**: Subscribers must have short, valid email formats. Reads/lists of subscriptions must be protected from resource scraping; only the bootstrapped admin (`shaikhzubia20@gmail.com`) can list/read them.
4. **Immutable Identities**: Once written, profiles (`uid`) and reviews (`uid`) cannot be reattached to other owners during updates.
5. **No Self-Assigned Privileges**: Users cannot change global system authorizations. Roles or privilege fields must never be changeable.

---

## 2. The "Dirty Dozen" Payloads

Payloads designed to attempt bypass of security restrictions and verification checks.

| ID | Collection | Target Path / Operation | Exploitation Objective | Malicious Payload / Context |
|---|---|---|---|---|
| 1 | `/users` | `create` / Custom UID spoofing | Attempt to register with a UID that does not match authenticated user | `{ "uid": "victim_uid_123", "displayName": "Attacker", "createdAt": "request.time" }` |
| 2 | `/users` | `create` / Time tampering | Attempt to write static/historic client timestamps | `{ "uid": "attacker_uid", "displayName": "Spoofer", "createdAt": "2020-01-01T00:00:00Z" }` |
| 3 | `/users` | `update` / Modify immutable uid | Attempt to reassign owner of an existing user profile record | `{ "uid": "hijacked_uid", "displayName": "Legit User" }` |
| 4 | `newsletterSubscribers` | `create` / Payload Bloating | Injecting massive (> 1KB) string characters into waitlist forms | `{ "email": "a".repeat(2000) + "@hack.com", "createdAt": "request.time" }` |
| 5 | `newsletterSubscribers` | `list` / Database Scraping | Unauthenticated user querying the list of all emails | `getDocs(collection(db, "newsletterSubscribers"))` (No Auth/Regular Auth) |
| 6 | `testimonials` | `create` / Spoofing developer ID | Create review pretending to be another logged-in profile | `{ "name": "Fake Name", "role": "Hacker", "content": "Spoofed", "rating": 5, "uid": "someone_else_uid", "initials": "FN", "createdAt": "request.time" }` |
| 7 | `testimonials` | `create` / Bounds violation - Rating | Write invalid rating scale (e.g. 10 stars or -1 stars) | `{ "name": "Abuser", "role": "QA", "content": "Very bad", "rating": 99, "uid": "attacker_uid", "initials": "AB", "createdAt": "request.time" }` |
| 8 | `testimonials` | `create` / Missing required fields | Missing initials and role fields but still inserting data | `{ "name": "NoInfo", "content": "Missing fields", "rating": 5, "uid": "attacker_uid", "createdAt": "request.time" }` |
| 9 | `testimonials` | `update` / Modifying historic reviews | Regular user attempting to alter critical review fields (content/rating) | `{ "content": "Modified after the fact", "updatedAt": "request.time" }` (Should block updates or restrict update actions) |
| 10 | `testimonials` | `delete` / Sabotaging reviews | Saboteur attempting to delete someone else's posted testimonial | `deleteDoc(doc(db, "testimonials", "testimonial_abc"))` by arbitrary non-owner |
| 11 | `/users` | `create` / Injection | Register database ID with unsafe characters (ID Poisoning) | `{userId} = "user-id-with-$$$-malicious-characters-and-extremely-long-payload-bloat"` |
| 12 | `newsletterSubscribers` | `update` / Sabotaging subscriber emails | Target endpoint to corrupt waitlist emails after entry | `updateDoc(doc(db, "newsletterSubscribers", "sub_xyz"), { "email": "corrupt@gmail.com" })` |

---

## 3. The Test Runner (`firestore.rules.test.ts`)

The automated TypeScript test suite to verify rules and ensure they robustly reject the Dirty Dozen threat vectors.

```typescript
import { 
  assertFails, 
  assertSucceeds, 
  initializeTestEnvironment, 
  RulesTestEnvironment 
} from "@firebase/rules-unit-testing";
import { readFileSync } from "fs";

let testEnv: RulesTestEnvironment;

beforeAll(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: "spheric-arcade-wjkjx",
    firestore: {
      rules: readFileSync("firestore.rules", "utf8"),
      host: "localhost",
      port: 8080
    }
  });
});

afterAll(async () => {
  await testEnv.cleanup();
});

describe("ApexSaaS Security Rules Tests", () => {
  beforeEach(async () => {
    await testEnv.clearFirestore();
  });

  test("Blocked 1: Custom UID Spoofing during profile creation", async () => {
    const maliciousUserDb = testEnv.authenticatedContext("attacker_uid").firestore();
    const maliciousWrite = maliciousUserDb.doc("users/attacker_uid");
    await assertFails(maliciousWrite.set({
      uid: "victim_uid_123", // Exploitation attempt
      displayName: "Attacker",
      createdAt: new Date()
    }));
  });

  test("Blocked 4: Payload Bloating on newsletter subscribers", async () => {
    const publicDb = testEnv.unauthenticatedContext().firestore();
    const tooLongEmail = "a".repeat(1100) + "@test.com";
    await assertFails(publicDb.collection("newsletterSubscribers").add({
      email: tooLongEmail,
      createdAt: new Date()
    }));
  });

  test("Blocked 5: Unauthenticated scrapers fetching newsletter email list", async () => {
    const anonymousDb = testEnv.unauthenticatedContext().firestore();
    await assertFails(anonymousDb.collection("newsletterSubscribers").get());
  });

  test("Blocked 6: Sibling ID Spoofing on testimonials", async () => {
    const userDb = testEnv.authenticatedContext("attacker_uid").firestore();
    await assertFails(userDb.collection("testimonials").add({
      name: "Malicious user",
      role: "Developer",
      content: "Nice site!",
      rating: 5,
      uid: "victim_uid_123", // Spoofed ID
      initials: "MU",
      createdAt: new Date()
    }));
  });

  test("Blocked 7: Rating scale bounds violations", async () => {
    const userDb = testEnv.authenticatedContext("attacker_uid").firestore();
    await assertFails(userDb.collection("testimonials").add({
      name: "Malicious user",
      role: "Developer",
      content: "Nice site!",
      rating: 99, // Out of bounds
      uid: "attacker_uid",
      initials: "MU",
      createdAt: new Date()
    }));
  });
});
```
