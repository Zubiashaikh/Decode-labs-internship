import { Check, ShieldCheck, Zap, Award } from "lucide-react";

export default function About() {
  const benefits = [
    {
      title: "Optimized server asset compilation",
      description: "Direct static bundling and optimized Node.js ESM compilation ensures lightning fast asset server-ready transfers."
    },
    {
      title: "Secure isolated sandbox contexts",
      description: "Isolate client API workspaces and environment secrets with state-of-the-art context encapsulation."
    },
    {
      title: "Automated container deployments",
      description: "Scale from 0 to thousands of concurrent microservices instances. Fully operational right inside secure Cloud Run configurations."
    }
  ];

  return (
    <section className="py-20 md:py-28 bg-neutral-50 dark:bg-neutral-900 overflow-hidden" id="product">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Text benefits */}
          <div className="lg:col-span-6 flex flex-col items-start space-y-6 text-left">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 tracking-wider uppercase bg-blue-100/60 dark:bg-blue-950/40 px-3 py-1.5 rounded-full inline-flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5" /> DEVELOPER PRODUCT BENEFIT
            </span>
            
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-neutral-900 dark:text-white leading-tight">
              Build Fully Automatic Services With Real-Time Pipeline Integration.
            </h2>
            
            <p className="font-sans text-base sm:text-lg text-neutral-600 dark:text-neutral-450 leading-relaxed">
              Why deal with virtual machines, scaling pools, and server orchestration? We manage and scale everything behind the scenes so your development flow remains lightweight and completely unblocked.
            </p>

            <div className="space-y-6 w-full pt-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0 mt-1 shadow-inner">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-bold text-neutral-900 dark:text-white mb-1.5">
                      {benefit.title}
                    </h3>
                    <p className="font-sans text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Visual Graphic Component */}
          <div className="lg:col-span-6 relative w-full max-w-lg mx-auto">
            {/* Background ambient glow shapes */}
            <div className="absolute top-10 right-10 -z-10 w-72 h-72 bg-blue-600/10 rounded-full filter blur-3xl"></div>
            <div className="absolute -bottom-10 left-10 -z-10 w-72 h-72 bg-indigo-500/15 rounded-full filter blur-2xl animate-pulse"></div>

            {/* Simulated Server Cluster Graphic Panel */}
            <div className="w-full glass-panel dark:dark-glass-panel rounded-2xl shadow-xl border border-neutral-200/50 dark:border-neutral-800/50 p-6">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-neutral-200/50 dark:border-neutral-850">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></div>
                  <span className="font-mono text-xs font-bold text-neutral-800 dark:text-white">Active Deployments</span>
                </div>
                <span className="text-[10px] font-mono text-neutral-450">PIPELINE ENGINE STATUS</span>
              </div>

              {/* Graphic Flow Layout */}
              <div className="space-y-4">
                {/* Node 1 */}
                <div className="bg-white/80 dark:bg-neutral-950/80 p-4 rounded-xl border border-neutral-200/50 dark:border-neutral-850 shadow-sm flex items-center justify-between group hover:border-emerald-500/50 hover:shadow-md transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-orange-100 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-display text-sm font-bold text-neutral-900 dark:text-white">Authentication Gateway</h4>
                      <p className="font-mono text-[10px] text-neutral-400 mt-0.5">Proxy: node-auth-west-4.local</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400">
                      SECURE
                    </span>
                    <p className="font-mono text-[9px] text-neutral-400 mt-1">SLA: 100%</p>
                  </div>
                </div>

                {/* Connection Line */}
                <div className="flex justify-center h-4">
                  <div className="w-0.5 h-full bg-linear-to-b from-emerald-500 to-blue-500"></div>
                </div>

                {/* Node 2 */}
                <div className="bg-white/80 dark:bg-neutral-950/80 p-4 rounded-xl border border-neutral-200/50 dark:border-neutral-850 shadow-sm flex items-center justify-between group hover:border-blue-500/50 hover:shadow-md transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-display text-sm font-bold text-neutral-900 dark:text-white">GraphQL Analytics Engine</h4>
                      <p className="font-mono text-[10px] text-neutral-400 mt-0.5">Proxy: node-gql-router-1.local</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400">
                      ACTIVE
                    </span>
                    <p className="font-mono text-[9px] text-neutral-400 mt-1">SLA: 99.99%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
