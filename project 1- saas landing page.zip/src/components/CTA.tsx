import { useState, FormEvent } from "react";
import { Sparkles, ArrowRight, CheckCircle, Mail, AlertCircle } from "lucide-react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";

export default function CTA() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes("@")) return;

    setSubmitting(true);
    setErrorMsg("");

    try {
      await addDoc(collection(db, "newsletterSubscribers"), {
        email: email.trim(),
        createdAt: serverTimestamp(),
      });
      setSubmitted(true);
      setEmail("");
    } catch (err: any) {
      console.error("Subscription error:", err);
      setErrorMsg("Failed to join. Please try again or check your parameters.");
      try {
        handleFirestoreError(err, OperationType.CREATE, "newsletterSubscribers");
      } catch (loggedErr) {
        // Logged gracefully
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-20 md:py-28 bg-white dark:bg-neutral-950 relative overflow-hidden" id="cta">
      {/* Visual background details */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -z-10 w-[700px] h-[700px] bg-blue-600/5 rounded-full filter blur-3xl"></div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Glow bordered container layout */}
        <div className="relative rounded-3xl overflow-hidden bg-neutral-900 text-white shadow-2xl p-8 sm:p-12 md:p-16 border border-neutral-800">
          
          {/* Subtle grid elements inside card */}
          <div className="absolute inset-0 opacity-15 bg-size-20 bg-repeat bg-center" style={{ backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)" }}></div>
          <div className="absolute -top-10 -right-10 w-60 h-60 bg-blue-500/20 rounded-full filter blur-3xl animate-pulse"></div>

          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6 flex flex-col items-center">
            
            {/* Sparkle badge */}
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/25 text-blue-400 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> ACCELERATE YOUR GROWTH
            </span>

            {/* Title */}
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight leading-tight">
              Ready to Sync Your Data Infrastructure?
            </h2>

            {/* Description */}
            <p className="font-sans text-sm sm:text-base text-neutral-400 max-w-2xl leading-relaxed">
              Create up to 10 automated serverless pipelines on our free starter tier. Setup takes less than 5 minutes. No complex containers, no credit card required.
            </p>

            {/* Interactive Subscription Form */}
            {submitted ? (
              <div className="flex flex-col items-center gap-3 bg-neutral-950/60 p-6 rounded-2xl border border-emerald-500/30 text-emerald-400 animate-fade-in-up mt-4 max-w-md w-full">
                <CheckCircle className="w-8 h-8 text-emerald-500" />
                <h3 className="font-display font-bold text-base text-white">Project Sandbox Created!</h3>
                <p className="font-sans text-xs text-neutral-400 text-center leading-relaxed">
                  We sent a secure setup token to your email inbox. Log in to start configuring your first endpoint.
                </p>
              </div>
            ) : (
              <div className="w-full max-w-md flex flex-col items-center gap-3">
                <form onSubmit={handleSubmit} className="w-full flex flex-col sm:flex-row gap-3 pt-4 inline-block">
                  <div className="relative flex-1">
                    <span className="absolute left-[18px] top-1/2 -translate-y-1/2 text-neutral-500">
                      <Mail className="w-4 h-4" />
                    </span>
                    <input
                      type="email"
                      required
                      value={email}
                      disabled={submitting}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter school or company email"
                      className="w-full bg-neutral-950 border border-neutral-800 hover:border-neutral-700 focus:border-blue-500 rounded-xl py-3 px-11 text-sm font-sans text-white focus:outline-none placeholder-neutral-500 shadow-inner disabled:opacity-55"
                      aria-label="Email address for starter pipeline invitation"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/10 hover:shadow-blue-600/20 hover:translate-y-[-1px] transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-blue-600/50 disabled:translate-y-0 cursor-pointer"
                  >
                    {submitting ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        Join Starter Tier
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
                {errorMsg && (
                  <div className="flex items-center gap-1.5 text-rose-400 text-xs font-sans mt-1 bg-rose-500/10 border border-rose-500/25 px-3 py-1.5 rounded-xl">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errorMsg}
                  </div>
                )}
              </div>
            )}

            <p className="font-sans text-[11px] text-neutral-500 pt-2">
              By submitting, you agree to our standard terms & privacy regulations.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
