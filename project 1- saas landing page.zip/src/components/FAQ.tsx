import { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "How does the 14ms pipeline latency guarantee work?",
      answer: "We route active pipeline requests directly through lightning-fast regional edge node networks. By storing transient system secrets and configs directly in active memory clusters rather than checking slow persistent disk drives on every single call, we minimize routing overhead to a fraction of a millisecond."
    },
    {
      question: "Can I manage environment variables and authentication keys safely?",
      answer: "Yes, absolutely. Every project environment utilizes fully modern sandboxed storage. Your external API credentials, AWS tokens, or Stripe secret keys are stored securely using hardware-accelerated AES-256 encryption. They are completely invisible to standard clients."
    },
    {
      question: "What happens when my serverless pipelines exceed traffic limits?",
      answer: "Unlike traditional services that crash or return 429 Rate Limit errors, our elite failover mechanics scale up supplementary worker engines dynamically. Traffic loads are auto-balanced across regional endpoints to maintain 100% stable performance."
    },
    {
      question: "Do you offer full custom OAuth and Google Workspace triggers?",
      answer: "Yes. Within the integration directory, you can register OAuth-based callbacks securely. We have built-in secure adapters for standard services like Google Calendar, Sheets, Slack, and GitHub with pristine token refresh automated handlers."
    },
    {
      question: "Is there a free trial tier for individual project builders?",
      answer: "Definitely. Our free tier includes 10 active automations, custom isolated sandboxes, and full API log views. No credit card is required to set up your account and get your first system operational."
    }
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 md:py-28 bg-neutral-50 dark:bg-neutral-900 relative" id="faq">
      {/* Background visual detail */}
      <div className="absolute top-1/3 right-10 -translate-y-1/2 -z-10 w-96 h-96 bg-blue-500/5 rounded-full filter blur-3xl"></div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16 md:mb-20">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 tracking-wider uppercase bg-blue-100/60 dark:bg-blue-950/40 px-3 py-1.5 rounded-full inline-flex items-center gap-1.5_">
            <HelpCircle className="w-3.5 h-3.5" /> COMMON QUESTIONS
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Frequently Asked Queries.
          </h2>
          <p className="font-sans text-base text-neutral-600 dark:text-neutral-450 leading-relaxed max-w-2xl mx-auto">
            Got questions about integrations, security configurations, or trial scaling tiers? Find fast technical answers from our team below.
          </p>
        </div>

        {/* FAQ Accordion container */}
        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-white dark:bg-neutral-950 border border-neutral-200/50 dark:border-neutral-800/50 rounded-2xl overflow-hidden transition-all duration-300 shadow-xs hover:shadow-md hover:border-neutral-300 dark:hover:border-neutral-750"
              >
                {/* Accordion header button */}
                <button
                  onClick={() => handleToggle(index)}
                  className="w-full px-6 py-5 sm:px-8 sm:py-6 text-left flex items-start justify-between gap-4 font-display font-bold text-neutral-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-450 focus:outline-none transition-colors"
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${index}`}
                  id={`faq-button-${index}`}
                >
                  <span className="text-base sm:text-lg leading-snug">
                    {faq.question}
                  </span>
                  
                  {/* Chevron Arrow Toggle */}
                  <span className={`p-1 rounded-lg bg-neutral-100 dark:bg-neutral-850 text-neutral-500 shrink-0 transition-transform duration-300 ${isOpen ? "rotate-180 text-blue-600 bg-blue-50 dark:bg-blue-950/40" : ""}`}>
                    <ChevronDown className="w-5 h-5" />
                  </span>
                </button>

                {/* Accordion answer content */}
                <div
                  id={`faq-answer-${index}`}
                  role="region"
                  aria-labelledby={`faq-button-${index}`}
                  className={`transition-all duration-300 ease-in-out overflow-hidden ${
                    isOpen ? "max-h-96 opacity-100 border-t border-neutral-100 dark:border-neutral-850" : "max-h-0 opacity-0 pointer-events-none"
                  }`}
                >
                  <div className="px-6 py-5 sm:px-8 sm:py-6 text-sm text-neutral-600 dark:text-neutral-400 font-sans leading-relaxed">
                    {faq.answer}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
