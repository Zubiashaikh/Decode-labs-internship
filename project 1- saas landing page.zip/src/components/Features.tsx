import {
  Zap,
  Activity,
  Shield,
  Layers,
  Server,
  BarChart3,
  ArrowRight
} from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Zap,
      title: "Automated server pipelines",
      description: "Connect APIs and register heavy automations in seconds. Orchestrate logic seamlessly without provisioning virtual servers.",
      tag: "Engine"
    },
    {
      icon: Activity,
      title: "Lightweight logs routing",
      description: "Filter and stream metrics through isolated, blazing-fast channels. Keep server logs lightweight and searchable.",
      tag: "Logs"
    },
    {
      icon: Layers,
      title: "Multi-tenant sandboxing",
      description: "Sandbox developer environments safely inside automated environments. Spin up fresh namespaces with zero overlapping data.",
      tag: "Isolation"
    },
    {
      icon: Shield,
      title: "SSL secure tunneling",
      description: "Enterprise encryption out of the box. Fully automated SSL certificate registration and granular token control policies.",
      tag: "Security"
    },
    {
      icon: Server,
      title: "Elite failover mechanics",
      description: "99.99% active uptime guaranteed. Built-in system health monitoring routes client request loads to backup instances instantly.",
      tag: "Reliability"
    },
    {
      icon: BarChart3,
      title: "Instant live metrics",
      description: "Visualize data trends directly from active endpoints. Build beautiful dashboards to monitor performance pipelines in real-time.",
      tag: "Analytics"
    }
  ];

  return (
    <section className="py-20 md:py-28 bg-white dark:bg-neutral-950 relative" id="features">
      {/* Background shape */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -z-10 w-[600px] h-[600px] bg-neutral-100/40 dark:bg-neutral-900/10 rounded-full filter blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16 md:mb-24">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 tracking-wider uppercase bg-blue-50 dark:bg-blue-950/40 px-3.5 py-1.5 rounded-full">
            SYSTEM ENGINE CAPABILITIES
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Designed for Developers Who Value Extreme Speed.
          </h2>
          <p className="font-sans text-base sm:text-lg text-neutral-600 dark:text-neutral-450 leading-relaxed">
            Eliminate server boilerplate and focus purely on your product business logic. SyncSaaS integrates all core pipelines into one beautiful performance workspace.
          </p>
        </div>

        {/* Features Bento/Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feat, index) => {
            const Icon = feat.icon;
            return (
              <div
                key={index}
                className="group relative bg-neutral-50 dark:bg-neutral-900/60 p-6 sm:p-8 rounded-2xl border border-neutral-200/50 dark:border-neutral-800/50 hover:bg-white dark:hover:bg-neutral-900 shadow-sm hover:shadow-xl hover:translate-y-[-4px] transition-all duration-300 focus-within:ring-2 focus-within:ring-blue-500"
              >
                {/* Decorative border trail */}
                <div className="absolute inset-x-0 -bottom-px h-1 bg-gradient-to-r from-blue-500/0 via-blue-500/0 to-blue-500/0 group-hover:from-blue-500/20 group-hover:via-blue-500 group-hover:to-indigo-500/20 transition-all rounded-b-2xl duration-500"></div>

                {/* Card Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 shadow-inner">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest bg-neutral-100 dark:bg-neutral-800/80 px-2.5 py-1 rounded-md">
                    {feat.tag}
                  </span>
                </div>

                {/* Text Content */}
                <h3 className="font-display text-lg sm:text-xl font-bold text-neutral-900 dark:text-white mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {feat.title}
                </h3>
                <p className="font-sans text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed mb-6">
                  {feat.description}
                </p>

                {/* Accessible CTA Link inside Card */}
                <a
                  href="#cta"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 group-hover:gap-2.5 transition-all focus:outline-none"
                  aria-label={`Learn more about ${feat.title}`}
                >
                  Explore Documentation
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
