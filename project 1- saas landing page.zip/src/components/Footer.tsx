import { Zap, Github, Twitter, Linkedin, Mail } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const companyLinks = [
    { name: "About Us", href: "#product" },
    { name: "Blog", href: "#hero" },
    { name: "Press & Branding", href: "#hero" }
  ];

  const productLinks = [
    { name: "Features Tool", href: "#features" },
    { name: "Sandboxes", href: "#features" },
    { name: "System Metrics", href: "#statistics" }
  ];

  const legalLinks = [
    { name: "Terms of Service", href: "#hero" },
    { name: "Privacy Policy", href: "#hero" },
    { name: "License Agreements", href: "#hero" }
  ];

  return (
    <footer className="bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-200 dark:border-neutral-900 pt-16 pb-8 font-sans" aria-label="Footer Navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 pb-12 border-b border-neutral-200 dark:border-neutral-900">
          
          {/* Logo & Pitch */}
          <div className="md:col-span-5 flex flex-col items-start space-y-4">
            <a href="#" className="flex items-center gap-2 group focus:outline-none" aria-label="ApexSaaS Home">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
                <Zap className="w-4.5 h-4.5 fill-current" />
              </div>
              <span className="font-display font-bold text-lg tracking-tight text-neutral-900 dark:text-white">
                Apex<span className="text-blue-600">SaaS</span>
              </span>
            </a>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed max-w-sm">
              Connecting and scaling modern developer data infrastructure with lightweight, secure pipeline automations and instant regional syncing.
            </p>
            {/* Social Icons */}
            <div className="flex gap-4 pt-2">
              <a
                href="#"
                className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-neutral-850 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-label="Follow us on Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-neutral-850 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-label="Follow us on LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-neutral-850 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-label="View codebase on GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Nav columns */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:col-span-7 gap-8">
            {/* Column 1 */}
            <div className="flex flex-col space-y-4">
              <h4 className="text-xs font-bold text-neutral-950 dark:text-white uppercase tracking-wider">
                Product
              </h4>
              <nav className="flex flex-col space-y-2.5" aria-label="Product Links">
                {productLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-blue-500 dark:hover:text-blue-400 focus:outline-none focus:underline transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </nav>
            </div>

            {/* Column 2 */}
            <div className="flex flex-col space-y-4">
              <h4 className="text-xs font-bold text-neutral-950 dark:text-white uppercase tracking-wider">
                Company
              </h4>
              <nav className="flex flex-col space-y-2.5" aria-label="Company Links">
                {companyLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-blue-500 dark:hover:text-blue-400 focus:outline-none focus:underline transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </nav>
            </div>

            {/* Column 3 */}
            <div className="flex flex-col space-y-4 col-span-2 sm:col-span-1">
              <h4 className="text-xs font-bold text-neutral-950 dark:text-white uppercase tracking-wider">
                Legal
              </h4>
              <nav className="flex flex-col space-y-2.5" aria-label="Legal Links">
                {legalLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-blue-500 dark:hover:text-blue-400 focus:outline-none focus:underline transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </nav>
            </div>
          </div>

        </div>

        {/* Bottom footer bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 text-xs text-neutral-500 dark:text-neutral-450">
          <p>© {currentYear} ApexSaaS. All rights reserved.</p>
          <div className="flex items-center gap-1.5 focus-within:underline">
            <Mail className="w-3.5 h-3.5 text-neutral-400" />
            <span>Support:</span>
            <a href="mailto:support@apexsaas.io" className="hover:text-neutral-850 dark:hover:text-neutral-200 transition-colors">
              support@apexsaas.io
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
