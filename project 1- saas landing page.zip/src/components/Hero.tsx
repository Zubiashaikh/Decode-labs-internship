import { useState, useEffect } from "react";
import { ArrowRight, Play, CheckCircle2, TrendingUp, Cpu, Server, Shield } from "lucide-react";

export default function Hero() {
  const [activeTab, setActiveTab] = useState<"api" | "performance" | "security">("api");
  const [requestCount, setRequestCount] = useState(1054320);

  // Dynamic simulation on the interactive mock component
  useEffect(() => {
    const interval = setInterval(() => {
      setRequestCount((prev) => prev + Math.floor(Math.random() * 5) + 1);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden grid-bg" id="hero">
      {/* Dynamic Background Accents */}
      <div className="absolute top-0 right-0 -z-10 w-96 h-96 bg-blue-500/10 rounded-full filter blur-3xl animate-pulse"></div>
      <div className="absolute -bottom-10 left-10 -z-10 w-80 h-80 bg-emerald-500/5 rounded-full filter blur-2xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Hero Left Content */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6 text-left">
            {/* Tagline Announcement */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 border border-blue-100 dark:bg-blue-950/30 dark:border-blue-900/40 text-blue-700 dark:text-blue-300 text-xs font-semibold tracking-wide">
              <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-ping"></span>
              Introducing Automation Engine 2.0
            </div>

            {/* Main Headline */}
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-neutral-900 dark:text-white leading-[1.1]">
              Developers Sync Their{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">
                Data Infrastructure
              </span>{" "}
              Faster.
            </h1>

            {/* Supporting Copy */}
            <p className="font-sans text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl leading-relaxed">
              Connect external APIs, build secure automated pipelines, and track performance with enterprise grade analytics. Powered by direct server syncing with no complex configuration.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto pt-2">
              <a
                href="#cta"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-lg shadow-blue-600/10 hover:shadow-blue-600/20 hover:translate-y-[-1px] transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Start Free Trial
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href="#product"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-850 text-neutral-700 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-750 font-semibold hover:translate-y-[-1px] transition-all focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Play className="w-4 h-4 fill-current text-blue-600" />
                Watch Demo
              </a>
            </div>

            {/* Dynamic trust points */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-y-4 gap-x-6 pt-6 border-t border-neutral-200/50 dark:border-neutral-800/40 w-full">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">No Credit Card</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Unlimited Pipelines</span>
              </div>
              <div className="hidden md:flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">ISO-27001 Certified</span>
              </div>
            </div>
          </div>

          {/* Hero Right Interactive Mockup Dashboard */}
          <div className="lg:col-span-5 relative w-full lg:max-w-md mx-auto">
            <div className="absolute inset-0 bg-blue-500/20 blur-3xl -z-10 rounded-full scale-105"></div>
            
            {/* The Glass Panel Window Mockup */}
            <div className="w-full glass-panel dark:dark-glass-panel rounded-2xl shadow-2xl border border-neutral-200/60 dark:border-neutral-800/60 overflow-hidden">
              {/* Window Controls Tab header */}
              <div className="bg-neutral-100/80 dark:bg-neutral-950/80 border-b border-neutral-200/60 dark:border-neutral-850 px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-rose-500/80 block"></span>
                  <span className="w-3 h-3 rounded-full bg-amber-500/80 block"></span>
                  <span className="w-3 h-3 rounded-full bg-emerald-500/80 block"></span>
                </div>
                <div className="flex bg-neutral-200/60 dark:bg-neutral-850 rounded-lg p-0.5" role="tablist">
                  <button
                    onClick={() => setActiveTab("api")}
                    role="tab"
                    aria-selected={activeTab === "api"}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors focus:outline-none ${
                      activeTab === "api"
                        ? "bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-sm"
                        : "text-neutral-600 dark:text-neutral-400 hover:text-neutral-900"
                    }`}
                  >
                    API
                  </button>
                  <button
                    onClick={() => setActiveTab("performance")}
                    role="tab"
                    aria-selected={activeTab === "performance"}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors focus:outline-none ${
                      activeTab === "performance"
                        ? "bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-sm"
                        : "text-neutral-600 dark:text-neutral-400 hover:text-neutral-900"
                    }`}
                  >
                    Metrics
                  </button>
                  <button
                    onClick={() => setActiveTab("security")}
                    role="tab"
                    aria-selected={activeTab === "security"}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors focus:outline-none ${
                      activeTab === "security"
                        ? "bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-sm"
                        : "text-neutral-600 dark:text-neutral-400 hover:text-neutral-900"
                    }`}
                  >
                    Security
                  </button>
                </div>
              </div>

              {/* Inside Dashboard Window */}
              <div className="p-5 font-mono text-xs text-neutral-800 dark:text-neutral-100 flex flex-col space-y-4">
                {activeTab === "api" && (
                  <div className="space-y-3.5">
                    <div className="flex items-center justify-between text-neutral-500 text-[10px] pb-1 border-b border-neutral-200/50 dark:border-neutral-850">
                      <span>SYNC REQUESTS</span>
                      <span className="text-emerald-500 font-bold">● ACTIVE</span>
                    </div>
                    <div className="space-y-2">
                      <div className="bg-neutral-100/50 dark:bg-neutral-850/50 p-2.5 rounded-lg border border-neutral-200/30 dark:border-neutral-800/50 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <code className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100/60 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded">POST</code>
                          <span className="text-neutral-700 dark:text-neutral-300 font-semibold font-sans">/v2/pipelines/trigger</span>
                        </div>
                        <span className="text-[10px] text-neutral-500">200 OK</span>
                      </div>
                      <div className="bg-neutral-100/50 dark:bg-neutral-850/50 p-2.5 rounded-lg border border-neutral-200/30 dark:border-neutral-800/50 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <code className="text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-100/60 dark:bg-blue-950/40 px-1.5 py-0.5 rounded">GET</code>
                          <span className="text-neutral-700 dark:text-neutral-300 font-semibold font-sans">/v2/monitoring/metrics</span>
                        </div>
                        <span className="text-[10px] text-neutral-500">200 OK</span>
                      </div>
                    </div>
                    <div className="pt-2 text-center flex flex-col justify-center items-center">
                      <span className="text-[10px] text-neutral-400">Total API Synchronizations (Live)</span>
                      <span className="text-xl font-bold font-sans tracking-tight text-neutral-900 dark:text-white mt-1">
                        {requestCount.toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}

                {activeTab === "performance" && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-neutral-500 text-[10px] pb-1 border-b border-neutral-200/50 dark:border-neutral-850">
                      <span>AVERAGE DURATION</span>
                      <span className="text-blue-600 font-bold">14ms average</span>
                    </div>
                    
                    {/* Live Progress Metrics */}
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div className="p-3 bg-neutral-100/50 dark:bg-neutral-850/50 rounded-lg border border-neutral-200/30 dark:border-neutral-800/40">
                        <div className="flex items-center gap-1.5 text-neutral-500 text-[9px] font-sans">
                          <Cpu className="w-3.5 h-3.5" /> CPU OVERHEAD
                        </div>
                        <p className="font-sans text-base font-bold text-neutral-900 dark:text-white mt-1">0.03%</p>
                      </div>
                      <div className="p-3 bg-neutral-100/50 dark:bg-neutral-850/50 rounded-lg border border-neutral-200/30 dark:border-neutral-800/40">
                        <div className="flex items-center gap-1.5 text-neutral-500 text-[9px] font-sans">
                          <Server className="w-3.5 h-3.5" /> RAM USAGE
                        </div>
                        <p className="font-sans text-base font-bold text-neutral-900 dark:text-white mt-1">11.4MB</p>
                      </div>
                    </div>

                    <div className="pt-1.5">
                      <div className="flex items-center justify-between text-[10px] text-neutral-500 mb-1">
                        <span>PIPELINE VELOCITY LEVEL</span>
                        <span className="text-emerald-500 font-bold flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> Optimum</span>
                      </div>
                      <div className="w-full h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                        <div className="w-4/5 h-full bg-blue-600 rounded-full animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "security" && (
                  <div className="space-y-3.5">
                    <div className="flex items-center justify-between text-neutral-500 text-[10px] pb-1 border-b border-neutral-200/50 dark:border-neutral-850">
                      <span>ENDPOINT COMPLIANCE</span>
                      <span className="text-emerald-500 font-bold flex items-center gap-1">
                        <Shield className="w-3 h-3" /> Secure
                      </span>
                    </div>
                    
                    <div className="space-y-2 font-sans">
                      <div className="flex items-center justify-between text-xs py-1">
                        <span className="text-neutral-600 dark:text-neutral-450 hover:text-neutral-900">IP Filtering Range</span>
                        <span className="font-semibold px-2 py-0.5 bg-neutral-100 dark:bg-neutral-800 text-[10px] rounded text-neutral-700 dark:text-neutral-300">White-listed</span>
                      </div>
                      <div className="flex items-center justify-between text-xs py-1">
                        <span className="text-neutral-600 dark:text-neutral-450 hover:text-neutral-900">Request Rate Limit</span>
                        <span className="font-semibold px-2 py-0.5 bg-neutral-100 dark:bg-neutral-800 text-[10px] rounded text-neutral-700 dark:text-neutral-300">500 r/sec max</span>
                      </div>
                      <div className="flex items-center justify-between text-xs py-1">
                        <span className="text-neutral-600 dark:text-neutral-450 hover:text-neutral-900">AES-256 Cloud Keys</span>
                        <span className="font-semibold px-2 py-0.5 bg-emerald-100/70 dark:bg-emerald-950/40 text-[10px] text-emerald-600 dark:text-emerald-400 rounded">Enabled</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-neutral-900/5 dark:bg-neutral-900/50 -mx-5 -mb-5 px-5 py-3 border-t border-neutral-200/50 dark:border-neutral-850 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[10px] text-neutral-500">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Service operational
                  </div>
                  <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
                    View Network Dashboard
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
