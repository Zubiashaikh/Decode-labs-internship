import { useState, useEffect, useRef } from "react";
import { Gauge, Clock, CloudLightning, Users } from "lucide-react";

interface CounterProps {
  target: number;
  decimals?: number;
  duration?: number;
}

function AnimatedCounter({ target, decimals = 0, duration = 1500 }: CounterProps) {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          let startTime: number | null = null;

          const animate = (timestamp: number) => {
            if (!startTime) startTime = timestamp;
            const progress = Math.min((timestamp - startTime) / duration, 1);
            
            // Easing out quadratic
            const easeProgress = progress * (2 - progress);
            setCount(easeProgress * target);

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(target);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.1 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, [target, duration]);

  return (
    <span ref={elementRef}>
      {count.toFixed(decimals)}
    </span>
  );
}

export default function Statistics() {
  const stats = [
    {
      icon: Clock,
      value: 14,
      decimals: 0,
      suffix: "ms",
      title: "Average pipeline latency",
      desc: "Built on direct RAM event syncing, bypassing slow disk write pools."
    },
    {
      icon: CloudLightning,
      value: 99.99,
      decimals: 2,
      suffix: "%",
      title: "SLA service uptime",
      desc: "Distributed active clustering ensures seamless backup scaling."
    },
    {
      icon: Users,
      value: 142000,
      decimals: 0,
      suffix: "+",
      title: "Active system developers",
      desc: "Engineers syncing active workspaces across the globe."
    },
    {
      icon: Gauge,
      value: 4.8,
      decimals: 1,
      suffix: "B+",
      title: "Weekly network events",
      desc: "High volume data transfers, routed and optimized instantly."
    }
  ];

  return (
    <section className="py-20 md:py-24 bg-neutral-900 text-white relative overflow-hidden" id="statistics">
      {/* Visual glowing design tokens */}
      <div className="absolute top-0 left-10 -translate-y-1/2 w-72 h-72 bg-blue-500/10 rounded-full filter blur-3xl"></div>
      <div className="absolute bottom-10 right-10 translate-y-1/2 w-80 h-80 bg-indigo-500/10 rounded-full filter blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-2xl text-left space-y-4 mb-16 md:mb-20">
          <span className="text-xs font-bold text-blue-400 tracking-wider uppercase bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full">
            WEEKLY WORKLOAD STATS
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
            High Performance Core. Proven at Scale.
          </h2>
          <p className="font-sans text-base sm:text-lg text-neutral-400">
            Trusted by the world's most demanding developer engineering departments to transport, process, and synchronize mission-critical pipeline payloads.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="bg-neutral-950/60 p-6 sm:p-8 rounded-2xl border border-neutral-800/80 hover:border-neutral-700/80 hover:bg-neutral-950/90 transition-all group flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-neutral-800/80 text-blue-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-neutral-400 font-sans text-sm font-semibold mb-2">
                    {stat.title}
                  </h3>
                  <div className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-white mb-4 flex items-baseline">
                    <AnimatedCounter target={stat.value} decimals={stat.decimals} />
                    <span className="text-blue-500 ml-0.5">{stat.suffix}</span>
                  </div>
                </div>
                <p className="font-sans text-xs text-neutral-450 leading-relaxed border-t border-neutral-800/40 pt-4 mt-2">
                  {stat.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
