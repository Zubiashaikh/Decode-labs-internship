import { useState, useEffect, FormEvent } from "react";
import { Star, MessageSquare, Plus, Check, AlertCircle, Info, Send } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";

interface TestimonialData {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  uid: string;
  initials: string;
  createdAt: any;
}

const staticTestimonials = [
  {
    name: "Olivia Chen",
    role: "VP of Engineering at CloudVentures",
    initials: "OC",
    rating: 5,
    content: "ApexSaaS cut our automated data pipeline development cycle from weeks to a single afternoon. Our serverless triggers render instantly and scaling is completely flawless.",
    tag: "Enterprise Customer"
  },
  {
    name: "Marcus Sterling",
    role: "Founder at TaskFlow SaaS",
    initials: "MS",
    rating: 5,
    content: "Setting up isolated workspace environments was extremely frustrating before. With their multi-tenant sandboxes, our users get isolated databases automatically.",
    tag: "Indie Founder"
  },
  {
    name: "Sarah Jenkins",
    role: "Staff Infrastructure Lead at Optima",
    initials: "SJ",
    rating: 5,
    content: "Our European routing metrics speak for themselves. Latency dropped from an average of 180ms to a constant, stable 14ms. Truly stellar design architecture.",
    tag: "Infrastructure Lead"
  }
];

export default function Testimonials() {
  const { user, signIn } = useAuth();
  const [dynamicTestimonials, setDynamicTestimonials] = useState<TestimonialData[]>([]);
  
  // Review submission state
  const [role, setRole] = useState("");
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  // Real-time subscription to testimonials collection
  useEffect(() => {
    const q = query(collection(db, "testimonials"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs: TestimonialData[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        docs.push({
          id: doc.id,
          name: data.name || "Anonymous Developer",
          role: data.role || "Developer",
          content: data.content || "",
          rating: data.rating || 5,
          uid: data.uid || "",
          initials: data.initials || "U",
          createdAt: data.createdAt
        });
      });
      setDynamicTestimonials(docs);
    }, (error) => {
      console.error("Testimonials fetch failed:", error);
      try {
        handleFirestoreError(error, OperationType.GET, "testimonials");
      } catch (err) {
        // Handle internally
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSubmitReview = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!role.trim() || !content.trim()) {
      setErrorMsg("Please fill out all fields.");
      return;
    }
    if (content.length < 5) {
      setErrorMsg("Review content must be at least 5 characters.");
      return;
    }

    setSubmitting(true);
    setErrorMsg("");
    setSuccessMsg("");

    const nameParts = user.displayName ? user.displayName.split(" ") : ["D", "V"];
    const calculatedInitials = nameParts.length >= 2 
      ? (nameParts[0][0] + nameParts[1][0]).toUpperCase()
      : (nameParts[0][0] + (nameParts[0][1] || "")).toUpperCase();

    try {
      await addDoc(collection(db, "testimonials"), {
        name: user.displayName || "Anonymous Developer",
        role: role.trim(),
        content: content.trim(),
        rating: Number(rating),
        uid: user.uid,
        initials: calculatedInitials.substring(0, 4),
        createdAt: serverTimestamp()
      });
      
      setSuccessMsg("Success! Your review was saved on Firestore in real-time.");
      setRole("");
      setContent("");
      setRating(5);
    } catch (err: any) {
      console.error("Error creating testimonial:", err);
      setErrorMsg("Failed to upload. Ensure all fields observe rules limits.");
      try {
        handleFirestoreError(err, OperationType.CREATE, "testimonials");
      } catch (loggedErr) {
        // Handled
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Combine static and dynamic testimonials
  const allTestimonials = [...staticTestimonials, ...dynamicTestimonials.map(t => ({
    name: t.name,
    role: t.role,
    initials: t.initials,
    rating: t.rating,
    content: t.content,
    tag: "Community Member"
  }))];

  return (
    <section className="py-20 md:py-28 bg-white dark:bg-neutral-950 relative" id="testimonials">
      <div className="absolute inset-0 bg-neutral-50/50 dark:bg-neutral-900/10 pointer-events-none -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-16 md:mb-24">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 tracking-wider uppercase bg-blue-50 dark:bg-blue-950/40 px-3.5 py-1.5 rounded-full inline-flex items-center gap-1.5_">
            <MessageSquare className="w-3.5 h-3.5" /> DEVELOPER REVIEWS
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Loved by Developers. Trusted by Tech Leaders.
          </h2>
          <p className="font-sans text-base sm:text-lg text-neutral-600 dark:text-neutral-450 leading-relaxed">
            See how forward-thinking infrastructure teams use SyncSaaS to automate, optimize, and streamline their production event systems.
          </p>
        </div>

        {/* Testimonials Cards Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {allTestimonials.map((test, index) => (
            <div
              key={index}
              className="bg-neutral-50 dark:bg-neutral-900/60 p-6 sm:p-8 rounded-2xl border border-neutral-200/50 dark:border-neutral-800/50 hover:bg-white dark:hover:bg-neutral-900 shadow-sm hover:shadow-xl hover:translate-y-[-2px] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Stars and Tag Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex gap-0.5 text-amber-500" aria-label={`Rating: ${test.rating} stars`}>
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current stroke-amber-500" />
                    ))}
                  </div>
                  <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded">
                    {test.tag}
                  </span>
                </div>

                {/* Content */}
                <blockquote className="font-sans text-neutral-750 dark:text-neutral-300 text-sm leading-relaxed mb-6 italic">
                  "{test.content}"
                </blockquote>
              </div>

              {/* Author Info */}
              <div className="flex items-center gap-3.5 border-t border-neutral-200/50 dark:border-neutral-800/40 pt-5">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold shadow-md">
                  {test.initials}
                </div>
                <div>
                  <cite className="font-display text-sm font-bold text-neutral-900 dark:text-white not-italic block">
                    {test.name}
                  </cite>
                  <span className="text-xs text-neutral-500 dark:text-neutral-450 block mt-0.5">
                    {test.role}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Experience Submission Form Sub-section */}
        <div className="mt-20 max-w-2xl mx-auto rounded-3xl bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200/60 dark:border-neutral-800/50 p-6 sm:p-10 shadow-md">
          <div className="text-center space-y-2 mb-8">
            <h3 className="font-display text-xl font-bold text-neutral-900 dark:text-white">
              Post Your Own Review
            </h3>
            <p className="font-sans text-xs sm:text-sm text-neutral-500 dark:text-neutral-400">
              Submit an interactive review with real-time sync directly into our Firestore database.
            </p>
          </div>

          {user ? (
            <form onSubmit={handleSubmitReview} className="space-y-5">
              {/* Star Rating selector */}
              <div className="flex flex-col items-center gap-2">
                <span className="font-sans text-xs font-semibold text-neutral-500 uppercase tracking-widest block">
                  Select Rating
                </span>
                <div className="flex gap-1.5">
                  {[1, 2, 3, 4, 5].map((starValue) => {
                    const isFilled = hoverRating >= starValue || (!hoverRating && rating >= starValue);
                    return (
                      <button
                        type="button"
                        key={starValue}
                        onClick={() => setRating(starValue)}
                        onMouseEnter={() => setHoverRating(starValue)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="p-1 transition-transform hover:scale-110 focus:outline-none cursor-pointer"
                        aria-label={`Rate ${starValue} stars`}
                      >
                        <Star
                          className={`w-7 h-7 transition-colors ${
                            isFilled
                              ? "fill-current text-amber-500 stroke-amber-500"
                              : "text-neutral-300 dark:text-neutral-700 stroke-current"
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Company / Role Input */}
              <div>
                <label htmlFor="user-role" className="block text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-2">
                  Your Role / Company Affiliation
                </label>
                <input
                  id="user-role"
                  type="text"
                  required
                  disabled={submitting}
                  placeholder="e.g. Lead Dev at Acme Inc."
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 focus:border-blue-500 dark:focus:border-blue-500 rounded-xl py-2.5 px-4 text-sm font-sans focus:outline-none transition-colors"
                />
              </div>

              {/* Review content */}
              <div>
                <label htmlFor="user-content" className="block text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-2">
                  Review Statement (at least 5 characters)
                </label>
                <textarea
                  id="user-content"
                  required
                  rows={3}
                  disabled={submitting}
                  placeholder="Type your authentic review here and see it post instantly below!"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 focus:border-blue-500 dark:focus:border-blue-500 rounded-xl py-2.5 px-4 text-sm font-sans focus:outline-none transition-colors resize-none"
                />
              </div>

              {/* Actions, success and failure notifications */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                <div className="flex flex-col gap-1 w-full sm:max-w-xs">
                  {errorMsg && (
                    <div className="flex items-center gap-1.5 text-rose-500 dark:text-rose-400 text-xs font-sans bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 rounded-xl">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {errorMsg}
                    </div>
                  )}
                  {successMsg && (
                    <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 text-xs font-sans bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl">
                      <Check className="w-3.5 h-3.5" />
                      {successMsg}
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md hover:translate-y-[-1px] transition-all disabled:opacity-55 disabled:translate-y-0 cursor-pointer"
                >
                  {submitting ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      Post Testimonial
                      <Send className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            <div className="flex flex-col items-center gap-4 text-center p-6 bg-white dark:bg-neutral-950 rounded-2xl border border-neutral-200/50 dark:border-neutral-800/50">
              <Info className="w-8 h-8 text-blue-500" />
              <div className="space-y-1">
                <h4 className="font-display font-semibold text-sm text-neutral-800 dark:text-neutral-200">
                  Authenticate to Share Your Experience
                </h4>
                <p className="font-sans text-xs text-neutral-500 max-w-sm">
                  Sign in securely with Google to post your direct system validation testimonial. Feel free to rate us and see your feedback update in real-time.
                </p>
              </div>
              <button
                onClick={signIn}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-900 text-xs font-semibold shadow-md transition-colors cursor-pointer"
              >
                Sign In with Google
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

