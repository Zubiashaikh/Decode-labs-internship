import React, { createContext, useContext, useState, useEffect } from "react";
import { User, onAuthStateChanged } from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, loginWithGoogle, logoutUser, handleFirestoreError, OperationType } from "../lib/firebase";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: () => Promise<User>;
  signOut: () => Promise<void>;
  isSynced: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSynced, setIsSynced] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        setIsSynced(false);
        // Sync user details to /users/{uid} securely using serverTimestamp()
        const userDocRef = doc(db, "users", currentUser.uid);
        try {
          // First check if it already exists to prevent unnecessary writes if desired,
          // but we want to update/upsert to sync and log correctly.
          const docSnap = await getDoc(userDocRef);
          
          if (!docSnap.exists()) {
            await setDoc(userDocRef, {
              uid: currentUser.uid,
              displayName: currentUser.displayName || "Anonymous Developer",
              photoURL: currentUser.photoURL || "",
              createdAt: serverTimestamp() // Must match request.time as per firestore.rules
            });
          }
          setIsSynced(true);
        } catch (error) {
          console.error("Error syncing user profile:", error);
          // If we encounter a permission error or key structure error, log elegantly through our standardized handler
          try {
            handleFirestoreError(error, OperationType.WRITE, `users/${currentUser.uid}`);
          } catch (loggedErr) {
            // Log local error
          }
        }
      } else {
        setIsSynced(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = async () => {
    setLoading(true);
    try {
      const signedInUser = await loginWithGoogle();
      return signedInUser;
    } catch (error) {
      setLoading(false);
      throw error;
    }
  };

  const signOut = async () => {
    setLoading(true);
    try {
      await logoutUser();
      setUser(null);
      setIsSynced(false);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signOut, isSynced }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used inside an AuthProvider");
  }
  return context;
};
