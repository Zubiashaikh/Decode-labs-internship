# ApexSaaS Production-Ready Vanilla Codebase

Welcome to the **ApexSaaS Landing Page** single-project codebase. This distribution is built using **pure semantic HTML5, modern CSS3 variables/grid systems, and plain Vanilla ES6 JavaScript**. 

It is completely lightweight, accessibility compliant (WCAG contrast levels & full keyboard support), and contains zero hard framework dependencies.

---

## 📂 File Directory Structure

```text
/vanilla/
├── index.html              # Main index file with semantic landmarks and ARIA support
├── css/
│   └── styles.css          # Mobile-first CSS with CSS custom variables definition
└── js/
    └── scripts.js          # Core JS interaction logic (stats animations, accordions, menu)
```

---

## 🚀 How To Run Locally

No compilers, transpilers, or package installs are required. Since this is built on standard browser-native mechanics:

1. **Double-Click**: Simply double-click on `index.html` to open it directly in any modern desktop or mobile browser environment.
2. **Local Dev Server (Recommended)**: For proper routing or local sandbox mockups testing, run a simple local web server in the `/vanilla/` directory root:
   - **VS Code**: Install the *Live Server* extensions and click "Go Live".
   - **Node.js**: Run `npx serve .` inside the directory.
   - **Python**: Run `python3 -m http.server 8000` and navigate to `http://localhost:8000`.

---

## 🛠️ Production-Ready Optimization & Deployment Notes

When transitioning this codebase from a starting template to high-volume production deployments:

### 1. File Minification & Bundling
- **CSS**: Minify `/css/styles.css` using modern build tools like `lightningcss` or simple `clean-css` to peel out redundant spacing and comments.
- **JS**: Run `/js/scripts.js` through `Terser` or `esbuild` to compress lines and reduce payloads down to `<3KB` for ultra-fast mobile network execution.

### 2. High-Performance Asset Optimization
- Instead of downloading heavy layout fonts from Google Fonts at module-load, download the `.woff2` font files for **Inter** and **Space Grotesk** directly, and reference them locally in the CSS using `@font-face` rules. This eliminates external routing and cuts First Contentful Paint (FCP) metrics by up to 400ms.
- Preload critical core fonts inside the HTML `<head>` tag:
  ```html
  <link rel="preload" href="/fonts/inter-bold.woff2" as="font" type="font/woff2" crossorigin>
  ```

### 3. Progressive Enhancement Security
- If nesting custom scripts inside the HTML layout, define a **Content Security Policy (CSP)** to block Cross-Site Scripting (XSS).
- Add modern **Subresource Integrity (SRI)** hash values to your asset link tags during final staging.

### 4. Continuous Integration Deployments
- This folder structure integrates seamlessly with modern serverless CD platforms like **Netlify, Vercel, or GitHub Pages** by setting the root build folder configuration simply to standard `/vanilla/`. Only HTML, CSS and JS assets will compile.

---

## 🎨 Design System Variables

Modifying colors, typography fonts, or layout padding is incredibly easy. Simply update the CSS custom properties inside `/css/styles.css`:

```css
:root {
  --font-sans: 'Inter', sans-serif;
  --font-display: 'Space Grotesk', sans-serif;
  --color-primary: #2563eb;         /* Change this to match your core brand hex code */
  --color-neutral-900: #111827;     /* High-contrast heading text option */
}
```
