/**
 * ApexSaaS - Vanilla JavaScript Interaction Engine
 * Features: Responsive Nav, Interactive Tabs, Count-up Stats, Accordions, CTA Submit
 */

document.addEventListener("DOMContentLoaded", () => {
  // Initialize all modular scripts
  initStickyHeader();
  initMobileMenu();
  initHeroTabs();
  initFaqAccordions();
  initStatsCounter();
  initScrollReveal();
  initCtaForm();
});

/**
 * 1. Sticky Navigation Header Effect
 */
function initStickyHeader() {
  const header = document.querySelector(".header");
  if (!header) return;

  const handleScroll = () => {
    if (window.scrollY > 20) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  };

  window.addEventListener("scroll", handleScroll);
  handleScroll(); // Trigger initial state check
}

/**
 * 2. Mobile Drawer Navigation Toggle
 */
function initMobileMenu() {
  const menuTrigger = document.querySelector(".menu-trigger");
  const mobileMenu = document.querySelector(".mobile-menu-drawer");
  const menuLinks = document.querySelectorAll(".mobile-nav-link");

  if (!menuTrigger || !mobileMenu) return;

  const toggleMenu = () => {
    const isExpanded = menuTrigger.getAttribute("aria-expanded") === "true";
    menuTrigger.setAttribute("aria-expanded", !isExpanded);
    mobileMenu.classList.toggle("active");
    document.body.style.overflow = isExpanded ? "" : "hidden"; // Prevent background scrolling
  };

  menuTrigger.addEventListener("click", toggleMenu);

  // Close when links are clicked
  menuLinks.forEach((link) => {
    link.addEventListener("click", () => {
      menuTrigger.setAttribute("aria-expanded", "false");
      mobileMenu.classList.remove("active");
      document.body.style.overflow = "";
    });
  });
}

/**
 * 3. Hero Visual Mockup Tab switcher
 */
function initHeroTabs() {
  const tabButtons = document.querySelectorAll(".mockup-tab");
  const tabContents = document.querySelectorAll(".mockup-tab-content");

  if (tabButtons.length === 0) return;

  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetTab = btn.getAttribute("data-tab");

      // Deactivate all
      tabButtons.forEach((b) => b.classList.remove("active"));
      tabContents.forEach((c) => c.classList.remove("active"));

      // Activate clicked
      btn.classList.add("active");
      const activeContent = document.getElementById(`tab-content-${targetTab}`);
      if (activeContent) {
        activeContent.classList.add("active");
      }
    });
  });

  // Simple live loop simulating API synchronizations count increment
  const apiCounterEl = document.getElementById("api-counter-text");
  if (apiCounterEl) {
    let currentVal = 1054320;
    setInterval(() => {
      currentVal += Math.floor(Math.random() * 5) + 1;
      apiCounterEl.textContent = currentVal.toLocaleString();
    }, 1500);
  }
}

/**
 * 4. FAQ Accordion Expander
 */
function initFaqAccordions() {
  const faqItems = document.querySelectorAll(".faq-item");

  if (faqItems.length === 0) return;

  faqItems.forEach((item) => {
    const trigger = item.querySelector(".faq-trigger");
    const content = item.querySelector(".faq-content");

    if (!trigger || !content) return;

    trigger.addEventListener("click", () => {
      const isExpanded = trigger.getAttribute("aria-expanded") === "true";
      
      // Close all other FAQs for clean single accordions list
      faqItems.forEach((otherItem) => {
        if (otherItem !== item) {
          otherItem.classList.remove("active");
          otherItem.querySelector(".faq-trigger")?.setAttribute("aria-expanded", "false");
        }
      });

      // Toggle current FAQ
      trigger.setAttribute("aria-expanded", !isExpanded);
      item.classList.toggle("active");
    });
  });
}

/**
 * 5. Animated Counter Stats on Scroll Observer
 */
function initStatsCounter() {
  const counters = document.querySelectorAll("[data-counter-target]");
  if (counters.length === 0) return;

  const animate = (counter) => {
    const target = parseFloat(counter.getAttribute("data-counter-target"));
    const decimals = parseInt(counter.getAttribute("data-counter-decimals") || "0");
    const duration = 1500; // Animation length in ms
    let startTime = null;

    const countUp = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      // Easing out quadratic curves
      const easeProgress = progress * (2 - progress);
      const currentVal = easeProgress * target;
      
      counter.textContent = currentVal.toFixed(decimals);

      if (progress < 1) {
        requestAnimationFrame(countUp);
      } else {
        counter.textContent = target.toFixed(decimals);
      }
    };

    requestAnimationFrame(countUp);
  };

  // IntersectionObserver to start counting only when statistics section is in view
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const counter = entry.target;
          animate(counter);
          observer.unobserve(counter); // Animate strictly once
        }
      });
    },
    { threshold: 0.1 }
  );

  counters.forEach((counter) => observer.observe(counter));
}

/**
 * 6. Scroll-Triggered Reveal Animations Observer
 */
function initScrollReveal() {
  const revealElements = document.querySelectorAll(".scroll-reveal");
  if (revealElements.length === 0) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("revealed");
          observer.unobserve(entry.target); // Unobserve to capture once
        }
      });
    },
    { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
  );

  revealElements.forEach((el) => observer.observe(el));
}

/**
 * 7. Call To Action Form Submission Handler
 */
function initCtaForm() {
  const form = document.querySelector(".cta-form");
  const successMsg = document.querySelector(".cta-success-message");

  if (!form || !successMsg) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const input = form.querySelector(".cta-input");
    
    if (input && input.value.trim().includes("@")) {
      form.style.display = "none";
      successMsg.style.display = "block";
      successMsg.classList.add("animate-fade-in-up");
    }
  });
}
